"use strict"

//The purpose of "use strict" is to indicate that the code should be executed in "strict mode". It Wants always declare the variables

// alert("This is External");



// var a; //declairation
// a=20;  //assign
// console.log(a);
// document.write(a);
// alert(a);


//we are able to declare variable  name same so due to this reason var is outdated
var b=50;
var b=30;
console.log(b);

let c=20;
    c=40;
console.log(c);


//we are not able to change the values of constant varibales
const birtYear=2000;
   // birtYear=2010;
      console.log(birtYear);  


     var data="Ajay";
      console.log(data);


      //datatypes it holds the diffrent type of values

      let n=10;
      let m=10.7;
      let name="ajay";
      let tr=true;
      let a=null;
      let d;

      console.log(typeof d);
       

      //Implicit Type conversion
      var num="5"+2;
      var num1="5"-2;
      document.write(num +"<br>");
      document.write(num1 +"<br>");

    //   Explicit Type conversion 
    var str=String(123);
    var number=Number("132");
    document.write(typeof str +"<br>")
    document.write(typeof number)
    document.write("<br>")


    var x=parseFloat(prompt("Enter a Number"));
    var y=parseFloat(prompt("Enter a Number"));
    document.write("Value: "+ (x+y));

    let symbol = Symbol("description");
    console.log(symbol);



